@echo off
rem Cue for Windows installer  (c) 2026 Luc Porchet
rem Installs Cue for the current user (no admin rights needed).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\install.ps1"
