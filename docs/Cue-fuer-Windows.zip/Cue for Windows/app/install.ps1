﻿# Cue for Windows installer  (c) 2026 Luc Porchet
# Started by "Cue installieren.bat". Installs to %LOCALAPPDATA%\Cue, no admin rights needed.
# -Quiet: started by Cue itself for a required update (no questions, no pause, errors go to tmp\update-error.txt)
param([switch]$Quiet)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # makes Invoke-WebRequest much faster
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$IsGerman = (Get-Culture).TwoLetterISOLanguageName -eq "de"
function T([string]$en, [string]$de) { if ($IsGerman) { $de } else { $en } }

$Src = $PSScriptRoot
$Dir = Join-Path $env:LOCALAPPDATA "Cue"

try {
    Write-Host ""
    Write-Host "Cue for Windows  -  (c) 2026 Luc Porchet"
    Write-Host ""

    # A running Cue would lock its files (during an update it is closing itself anyway)
    if ($Quiet) { Start-Sleep -Seconds 2 }
    Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and $_.CommandLine -like "*\Cue\Cue.ps1*" } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    New-Item -ItemType Directory -Force -Path (Join-Path $Dir "tmp") | Out-Null

    Write-Host (T "1/4 Copying Cue ..." "1/4 Kopiere Cue ...")
    foreach ($f in @("Cue.ps1", "clip.ps1", "checkin.ps1", "Cue.vbs", "Cue.ico", "Cue.png", "Cue-intro.wav", "uninstall.ps1")) {
        Copy-Item -Force -Path (Join-Path $Src $f) -Destination (Join-Path $Dir $f)
    }
    Get-ChildItem $Dir -File | Unblock-File -ErrorAction SilentlyContinue

    $yt = Join-Path $Dir "yt-dlp.exe"
    Write-Host (T "2/4 Checking yt-dlp ..." "2/4 Pruefe yt-dlp ...")
    if (-not (Test-Path $yt)) {
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile $yt
    } else {
        & $yt -U | Out-Null
    }

    $ff = Join-Path $Dir "ffmpeg.exe"
    Write-Host (T "3/4 Checking ffmpeg (about 130 MB, the first time takes a moment) ..." "3/4 Pruefe ffmpeg (ca. 130 MB, beim ersten Mal dauert es etwas) ...")
    if (-not (Test-Path $ff) -or -not (Test-Path (Join-Path $Dir "ffprobe.exe"))) {
        $zip = Join-Path $env:TEMP "cue-ffmpeg.zip"
        $unz = Join-Path $env:TEMP "cue-ffmpeg"
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" -OutFile $zip
        if (Test-Path $unz) { Remove-Item -Recurse -Force $unz }
        Expand-Archive -Path $zip -DestinationPath $unz -Force
        foreach ($exe in @("ffmpeg.exe", "ffprobe.exe")) {
            $found = Get-ChildItem -Path $unz -Recurse -Filter $exe | Select-Object -First 1
            if (-not $found) { throw (T "ffmpeg download is incomplete." "ffmpeg Download ist unvollstaendig.") }
            Copy-Item -Force $found.FullName (Join-Path $Dir $exe)
        }
        Remove-Item -Recurse -Force $unz, $zip -ErrorAction SilentlyContinue
    }

    Write-Host (T "4/4 Creating shortcuts ..." "4/4 Erstelle Verknuepfungen ...")
    $sh = New-Object -ComObject WScript.Shell
    $wscript = Join-Path $env:SystemRoot "System32\wscript.exe"
    $targets = @(
        (Join-Path ([Environment]::GetFolderPath("Desktop")) "Cue.lnk"),
        (Join-Path ([Environment]::GetFolderPath("Programs")) "Cue.lnk")
    )
    foreach ($lnk in $targets) {
        $s = $sh.CreateShortcut($lnk)
        $s.TargetPath = $wscript
        $s.Arguments = '"' + (Join-Path $Dir "Cue.vbs") + '"'
        $s.WorkingDirectory = $Dir
        $s.IconLocation = (Join-Path $Dir "Cue.ico") + ",0"
        $s.Description = "Cue  -  (c) 2026 Luc Porchet"
        $s.Save()
    }
    $u = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath("Programs")) (T "Uninstall Cue.lnk" "Cue deinstallieren.lnk")))
    $u.TargetPath = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $u.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Dir "uninstall.ps1") + '"'
    $u.IconLocation = (Join-Path $Dir "Cue.ico") + ",0"
    $u.Save()

    Write-Host ""
    Write-Host (T "Done! Cue is on your desktop and in the Start menu." "Fertig! Cue ist auf dem Desktop und im Startmenue.")
    Start-Process -FilePath $wscript -ArgumentList ('"' + (Join-Path $Dir "Cue.vbs") + '"')
} catch {
    $msg = (T "Installation failed: " "Installation fehlgeschlagen: ") + $_.Exception.Message
    if ($Quiet) {
        # Cue shows this on its update screen; the old version is started again
        try { [IO.File]::WriteAllText((Join-Path $Dir "tmp\update-error.txt"), $msg, (New-Object System.Text.UTF8Encoding($false))) } catch {}
        $vbs = Join-Path $Dir "Cue.vbs"
        if (Test-Path $vbs) { Start-Process -FilePath (Join-Path $env:SystemRoot "System32\wscript.exe") -ArgumentList ('"' + $vbs + '"') }
        exit 1
    }
    Write-Host ""
    Write-Host $msg -ForegroundColor Red
}
if ($Quiet) { exit 0 }
Write-Host ""
Read-Host (T "Press Enter to close this window" "Enter druecken, um dieses Fenster zu schliessen") | Out-Null
