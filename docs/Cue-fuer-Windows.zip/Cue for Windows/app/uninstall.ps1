﻿# Removes Cue for Windows  (c) 2026 Luc Porchet
# Your downloaded clips in the Downloads folder stay where they are.
$IsGerman = (Get-Culture).TwoLetterISOLanguageName -eq "de"
function T([string]$en, [string]$de) { if ($IsGerman) { $de } else { $en } }
$Dir = Join-Path $env:LOCALAPPDATA "Cue"

$answer = Read-Host (T "Remove Cue from this PC? Your clips stay in Downloads. (y/n)" "Cue von diesem PC entfernen? Deine Clips bleiben in Downloads. (j/n)")
if ($answer -notmatch '^(y|j)') { exit 0 }

Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and ($_.CommandLine -like "*\Cue\Cue.ps1*" -or $_.CommandLine -like "*\Cue\clip.ps1*") } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1

foreach ($lnk in @(
    (Join-Path ([Environment]::GetFolderPath("Desktop")) "Cue.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Programs")) "Cue.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Programs")) "Uninstall Cue.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Programs")) "Cue deinstallieren.lnk"))) {
    Remove-Item -Force $lnk -ErrorAction SilentlyContinue
}
# PowerShell has read this script into memory, so its own folder can be removed
Remove-Item -Recurse -Force $Dir -ErrorAction SilentlyContinue
Write-Host (T "Cue has been removed." "Cue wurde entfernt.")
Start-Sleep -Seconds 2
