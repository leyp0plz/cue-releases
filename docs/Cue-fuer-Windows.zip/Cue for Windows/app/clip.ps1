﻿# Cue for Windows: download and cut  (c) 2026 Luc Porchet
# clip.ps1 MODE LINK START END   MODE = audio | video | both, "_" = empty
# (not "-": PowerShell would read an argument starting with "-" as a parameter name)
# Same logic as clip.sh on the Mac:
#   Audio: best audio track (no DRC) -> Apple Lossless 24 bit .m4a, cut sample-accurately
#   Video: highest resolution -> H.264 .mp4, H.264 source without a cut is only copied
# Progress: %LOCALAPPDATA%\Cue\tmp\status (last line "P 45.3%" or "T text")
# Result: paths in tmp\out (one per line), error text in tmp\err, exit code 0 = ok
param([string]$Mode, [string]$Link, [string]$Start = "_", [string]$End = "_")

$ErrorActionPreference = "Continue"
$Dir = Join-Path $env:LOCALAPPDATA "Cue"
$Tmp = Join-Path $Dir "tmp"
$YtDlp = Join-Path $Dir "yt-dlp.exe"
$FFmpeg = Join-Path $Dir "ffmpeg.exe"
$FFprobe = Join-Path $Dir "ffprobe.exe"
$Status = Join-Path $Tmp "status"
$Log = Join-Path $Tmp "last.log"
$OutFile = Join-Path $Tmp "out"
$ErrFile = Join-Path $Tmp "err"
$Utf8 = New-Object System.Text.UTF8Encoding($false)

New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
foreach ($f in @($Status, $Log, $OutFile, $ErrFile)) { [IO.File]::WriteAllText($f, "", $Utf8) }
$W = Join-Path $Tmp ("run-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $W | Out-Null

function Say([string]$t) { [IO.File]::AppendAllText($Status, "T $t`r`n", $Utf8) }
function Pct([string]$line) { [IO.File]::AppendAllText($Status, "$line`r`n", $Utf8) }
function Fail([string]$msg) {
    [IO.File]::WriteAllText($ErrFile, $msg, $Utf8)
    Remove-Item -Recurse -Force $W -ErrorAction SilentlyContinue
    exit 1
}
function Lang([string]$en, [string]$de) { if ((Get-Culture).TwoLetterISOLanguageName -eq "de") { $de } else { $en } }

# 2.22.13 / 2,22,13 / 2:22:13 -> 2:22:13
function NormTime([string]$t) {
    if ($t -eq "_" -or $t -eq "-") { return "" }
    $t = ($t -replace '\s', '') -replace '[.,]', ':'
    if ($t -eq "") { return "" }
    if ($t -notmatch '^\d+(:\d{1,2}){0,2}$') { Fail ((Lang "Invalid time: " "Ungültige Zeit: ") + $t + (Lang " (example: 2.22.13)" " (Beispiel: 2.22.13)")) }
    return $t
}
function Secs([string]$t) { $s = 0; foreach ($p in $t.Split(':')) { $s = $s * 60 + [int]$p }; return $s }

# Downloads folder (also when moved to another drive)
function DownloadsDir {
    try { $p = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path; if ($p) { return $p } } catch {}
    return (Join-Path $env:USERPROFILE "Downloads")
}

if (@("audio", "video", "both") -notcontains $Mode) { Fail "MODE must be audio, video or both" }
$Link = $Link -replace '\s', ''
if ($Link -eq "" -or $Link -eq "_") { Fail (Lang "No link entered." "Kein Link eingegeben.") }
$StartT = NormTime $Start
$EndT = NormTime $End
if ($StartT -eq "") { $EndT = "" }
$Out = DownloadsDir

# Keep yt-dlp current (YouTube changes often), at most once a week
if ((Get-Item $YtDlp).LastWriteTime -lt (Get-Date).AddDays(-7)) {
    Say (Lang "Updating yt-dlp …" "Aktualisiere yt-dlp …")
    & $YtDlp -U 2>> $Log | Out-Null
    (Get-Item $YtDlp).LastWriteTime = Get-Date
}

if ($Mode -eq "audio") {
    Say (Lang "Downloading audio …" "Lade Audio …")
    $fmt = @("-f", "ba[format_id!*=drc]/ba/b")
} else {
    Say (Lang "Downloading video in the highest resolution …" "Lade Video in höchster Auflösung …")
    $fmt = @("-f", "bv*[format_id!*=drc]+ba[format_id!*=drc]/bv*+ba/b", "--merge-output-format", "mkv")
}

$pathFile = Join-Path $W "path"
$durFile = Join-Path $W "duration"
$ytArgs = $fmt + @("--no-playlist", "--no-warnings", "--newline", "--progress",
    "--progress-template", "download:P %(progress._percent_str)s",
    "--ffmpeg-location", $Dir, "-o", (Join-Path $W "%(title).150B.%(ext)s"),
    "--print-to-file", "after_move:filepath", $pathFile,
    "--print-to-file", "after_move:duration", $durFile, $Link)
& $YtDlp @ytArgs 2>> $Log | ForEach-Object { if ($_ -like "P *") { Pct $_ } }
if (-not (Test-Path $pathFile) -or (Get-Item $pathFile).Length -eq 0) {
    $why = (Get-Content $Log -ErrorAction SilentlyContinue | Where-Object { $_ -match 'ERROR' } | Select-Object -Last 3) -join "`r`n"
    Fail ((Lang "Download failed:" "Download fehlgeschlagen:") + "`r`n" + $why)
}
$F = ([IO.File]::ReadAllLines($pathFile, $Utf8) | Where-Object { $_ -ne "" } | Select-Object -Last 1)
$Name = [IO.Path]::GetFileNameWithoutExtension($F)

# Length of the result in seconds (for the progress while encoding)
$Dur = 0
if (Test-Path $durFile) { $raw = ([IO.File]::ReadAllLines($durFile, $Utf8) | Select-Object -Last 1); if ($raw -match '^(\d+)') { $Dur = [int]$Matches[1] } }
$Label = ""; $Cut = @()
if ($StartT -ne "") {
    $Label = " (" + ($StartT -replace ':', '.')
    if ($EndT -ne "") { $Label += (Lang " to " " bis ") + ($EndT -replace ':', '.') }
    $Label += ")"
    $Cut = @("-ss", $StartT)
    if ($EndT -ne "") { $Cut += @("-to", $EndT) }
    $s0 = Secs $StartT
    if ($EndT -ne "") { $Dur = (Secs $EndT) - $s0 } else { $Dur = $Dur - $s0 }
}

# ffmpeg with percent progress; returns $true on success
function FF([string[]]$ffArgs) {
    $all = @("-y", "-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1") + $ffArgs
    & $FFmpeg @all 2>> $Log | ForEach-Object {
        if ($_ -match '^out_time_us=(\d+)' -and $Dur -gt 0) {
            $p = [Math]::Min(100, [double]$Matches[1] / 10000 / $Dur)
            $line = ("P {0:0.0}%" -f $p).Replace(',', '.')
            Pct $line
        }
    }
    return ($LASTEXITCODE -eq 0)
}
function Codec([string]$kind) {
    $c = & $FFprobe -v error -select_streams "$($kind):0" -show_entries stream=codec_name -of csv=p=0 $F 2>$null
    return ("" + $c).Trim()
}

# Apple Lossless, 24 bit, sample rate of the source
$Alac = @("-vn", "-map", "0:a:0", "-c:a", "alac", "-sample_fmt", "s32p", "-bits_per_raw_sample", "24")
$results = @()

if ($Mode -eq "both") {
    Say (Lang "Saving lossless audio …" "Speichere Audio verlustfrei …")
    $A = Join-Path $Out ($Name + $Label + ".m4a")
    if (-not (FF ($Cut + @("-i", $F) + $Alac + @($A)))) { Fail (Lang "Could not save the audio." "Audio konnte nicht gespeichert werden.") }
}

if ($Mode -eq "audio") {
    $R = Join-Path $Out ($Name + $Label + ".m4a")
    if ($StartT -ne "") { Say (Lang "Cutting the clip losslessly …" "Schneide Ausschnitt verlustfrei …") } else { Say (Lang "Saving lossless audio …" "Speichere Audio verlustfrei …") }
    if (-not (FF ($Cut + @("-i", $F) + $Alac + @($R)))) { Fail (Lang "Could not save the audio." "Audio konnte nicht gespeichert werden.") }
} else {
    $R = Join-Path $Out ($Name + $Label + ".mp4")
    $vc = Codec "v"; $ac = Codec "a"
    if ($ac -eq "aac" -and $StartT -eq "") { $aopt = @("-c:a", "copy") } else { $aopt = @("-c:a", "aac", "-b:a", "320k") }
    $map = @("-map", "0:v:0", "-map", "0:a:0?")
    $tail = $aopt + @("-movflags", "+faststart", $R)
    if ($vc -eq "h264" -and $StartT -eq "") {
        Say (Lang "Saving video …" "Speichere Video …")
        if (-not (FF (@("-i", $F) + $map + @("-c:v", "copy") + $tail))) { Fail (Lang "Could not save the video." "Video konnte nicht gespeichert werden.") }
    } else {
        if ($StartT -ne "") { Say (Lang "Cutting video frame-accurately …" "Schneide Video framegenau …") } else { Say (Lang "Converting video to H.264 …" "Wandle Video in H.264 um …") }
        # Graphics card encoders first (fast, very high quality), then x264 almost lossless
        $encoders = @(
            @("-c:v", "h264_nvenc", "-preset", "p6", "-rc", "vbr", "-cq", "16", "-b:v", "0", "-pix_fmt", "yuv420p"),
            @("-c:v", "h264_qsv", "-global_quality", "18", "-pix_fmt", "nv12"),
            @("-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp", "-qp_i", "16", "-qp_p", "18", "-pix_fmt", "nv12"),
            @("-c:v", "libx264", "-crf", "16", "-preset", "medium", "-pix_fmt", "yuv420p")
        )
        $ok = $false
        foreach ($enc in $encoders) {
            if (FF ($Cut + @("-i", $F) + $map + $enc + $tail)) { $ok = $true; break }
        }
        if (-not $ok) { Fail (Lang "Could not save the video." "Video konnte nicht gespeichert werden.") }
    }
}

$results += $R
if ($Mode -eq "both") { $results += $A }
[IO.File]::WriteAllText($OutFile, ($results -join "`r`n"), $Utf8)
# History for the list "Previous clips" in Cue (newest line last)
[IO.File]::AppendAllText((Join-Path $Dir "history.txt"), (($results -join "`r`n") + "`r`n"), $Utf8)
Say (Lang "Done" "Fertig")
Remove-Item -Recurse -Force $W -ErrorAction SilentlyContinue
exit 0
