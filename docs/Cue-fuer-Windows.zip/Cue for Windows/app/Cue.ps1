﻿# Cue for Windows 1.5  (c) 2026 Luc Porchet
# Window app for clip.ps1 (audio lossless, video up to 4K). Same keys and revocation list as Cue on the Mac.
# Start: wscript.exe Cue.vbs (no console window)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class CueNative {
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);
    [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
    // Windows 11: rounded corners for the borderless start window (no effect on Windows 10)
    public static void RoundCorners(IntPtr hwnd) { int v = 2; try { DwmSetWindowAttribute(hwnd, 33, ref v, 4); } catch { } }
}
'@
try { [void][CueNative]::SetCurrentProcessExplicitAppUserModelID("LucPorchet.Cue") } catch {}
try { [void][CueNative]::SetProcessDPIAware() } catch {}
[System.Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$Version = "1.5"
$Dir = Join-Path $env:LOCALAPPDATA "Cue"
$Tmp = Join-Path $Dir "tmp"
$SettingsFile = Join-Path $Dir "settings.json"
$HistoryFile = Join-Path $Dir "history.txt"
$Utf8 = New-Object System.Text.UTF8Encoding($false)
$PublicKey = [Convert]::FromBase64String("KBvAvhzPvL+E934J1PzhhqxTaiVvek04jfSCihQ+grg=")
# Destroyed keys without revocation list (same list as License.swift)
$Destroyed = @("ED604641")
$IsGerman = (Get-Culture).TwoLetterISOLanguageName -eq "de"
function T([string]$en, [string]$de) { if ($IsGerman) { $de } else { $en } }
$Culture = if ($IsGerman) { New-Object Globalization.CultureInfo("de-CH") } else { New-Object Globalization.CultureInfo("en-GB") }

# Ed25519 signature check (RFC 8032). Windows has none built in, so it is compiled here once at start.
Add-Type -ReferencedAssemblies System.Numerics -TypeDefinition @'
using System;
using System.Numerics;
using System.Security.Cryptography;

public static class CueCrypto {
    static readonly BigInteger P = BigInteger.Pow(2, 255) - 19;
    static readonly BigInteger L = BigInteger.Pow(2, 252) + BigInteger.Parse("27742317777372353535851937790883648493");
    static readonly BigInteger Mask = BigInteger.Pow(2, 255) - 1;
    static readonly BigInteger D;
    static readonly BigInteger SqrtM1;
    static readonly BigInteger[] G;

    static CueCrypto() {
        D = Mod(new BigInteger(-121665) * Inv(new BigInteger(121666)));
        SqrtM1 = BigInteger.ModPow(2, (P - 1) / 4, P);
        BigInteger gy = Mod(new BigInteger(4) * Inv(new BigInteger(5)));
        BigInteger gx;
        TryRecoverX(gy, 0, out gx);
        G = new BigInteger[] { gx, gy, BigInteger.One, Mod(gx * gy) };
    }

    static BigInteger Mod(BigInteger a) { BigInteger r = a % P; return r.Sign < 0 ? r + P : r; }
    static BigInteger Inv(BigInteger x) { return BigInteger.ModPow(Mod(x), P - 2, P); }

    static BigInteger[] Add(BigInteger[] p, BigInteger[] q) {
        BigInteger a = Mod((p[1] - p[0]) * (q[1] - q[0]));
        BigInteger b = Mod((p[1] + p[0]) * (q[1] + q[0]));
        BigInteger c = Mod(2 * p[3] * q[3] * D);
        BigInteger d = Mod(2 * p[2] * q[2]);
        BigInteger e = Mod(b - a), f = Mod(d - c), g = Mod(d + c), h = Mod(b + a);
        return new BigInteger[] { Mod(e * f), Mod(g * h), Mod(f * g), Mod(e * h) };
    }

    static BigInteger[] Mul(BigInteger s, BigInteger[] pt) {
        BigInteger[] q = new BigInteger[] { BigInteger.Zero, BigInteger.One, BigInteger.One, BigInteger.Zero };
        while (s.Sign > 0) {
            if (!s.IsEven) q = Add(q, pt);
            pt = Add(pt, pt);
            s = s >> 1;
        }
        return q;
    }

    static bool Eq(BigInteger[] p, BigInteger[] q) {
        return Mod(p[0] * q[2] - q[0] * p[2]).IsZero && Mod(p[1] * q[2] - q[1] * p[2]).IsZero;
    }

    static bool TryRecoverX(BigInteger y, int sign, out BigInteger x) {
        x = BigInteger.Zero;
        if (y >= P) return false;
        BigInteger x2 = Mod((y * y - 1) * Inv(D * y * y + 1));
        if (x2.IsZero) return sign == 0;
        x = BigInteger.ModPow(x2, (P + 3) / 8, P);
        if (!Mod(x * x - x2).IsZero) x = Mod(x * SqrtM1);
        if (!Mod(x * x - x2).IsZero) return false;
        if ((x.IsEven ? 0 : 1) != sign) x = P - x;
        return true;
    }

    static BigInteger FromLE(byte[] b, int off, int len) {
        byte[] t = new byte[len + 1];
        Array.Copy(b, off, t, 0, len);
        return new BigInteger(t);
    }

    static BigInteger[] Decompress(byte[] b, int off) {
        BigInteger y = FromLE(b, off, 32) & Mask;
        int sign = (b[off + 31] >> 7) & 1;
        BigInteger x;
        if (!TryRecoverX(y, sign, out x)) return null;
        return new BigInteger[] { x, y, BigInteger.One, Mod(x * y) };
    }

    public static bool Verify(byte[] pub, byte[] msg, byte[] sig) {
        if (pub == null || msg == null || sig == null || pub.Length != 32 || sig.Length != 64) return false;
        BigInteger[] a = Decompress(pub, 0);
        BigInteger[] r = Decompress(sig, 0);
        if (a == null || r == null) return false;
        BigInteger s = FromLE(sig, 32, 32);
        if (s >= L) return false;
        byte[] buf = new byte[32 + 32 + msg.Length];
        Array.Copy(sig, 0, buf, 0, 32);
        Array.Copy(pub, 0, buf, 32, 32);
        Array.Copy(msg, 0, buf, 64, msg.Length);
        byte[] hash;
        using (SHA512 sha = SHA512.Create()) { hash = sha.ComputeHash(buf); }
        BigInteger h = FromLE(hash, 0, 64) % L;
        return Eq(Mul(s, G), Add(r, Mul(h, a)));
    }
}
'@

# ---------- Settings (%LOCALAPPDATA%\Cue\settings.json) ----------
function Load-Settings {
    $h = @{}
    if (Test-Path $SettingsFile) {
        try {
            $o = [IO.File]::ReadAllText($SettingsFile, $Utf8) | ConvertFrom-Json
            foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = [string]$p.Value }
        } catch {}
    }
    return $h
}
function Save-Settings { [IO.File]::WriteAllText($SettingsFile, ($script:S | ConvertTo-Json), $Utf8) }
function Get-Date-Setting([string]$name) {
    $v = $script:S[$name]
    if (-not $v) { return [DateTime]::MinValue }
    try { return [DateTime]::Parse($v, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind) } catch { return [DateTime]::MinValue }
}
function Set-Date-Setting([string]$name, [DateTime]$d) { $script:S[$name] = $d.ToUniversalTime().ToString("o") }

New-Item -ItemType Directory -Force -Path $Tmp | Out-Null
$script:S = Load-Settings

# ---------- Keys: CUE1.<data>.<signature>, revocation list: CUEREV1.<data>.<signature> ----------
function From-B64Url([string]$s) {
    $t = $s.Replace('-', '+').Replace('_', '/')
    while ($t.Length % 4 -ne 0) { $t += "=" }
    try { return ,([Convert]::FromBase64String($t)) } catch { return $null }
}
# $null = wrong format; otherwise @{ Valid = signature ok; Text = data }
function Get-SignedText([string]$raw, [string]$prefix) {
    $parts = ($raw -replace '\s', '').Split('.')
    if ($parts.Count -ne 3 -or $parts[0] -ne $prefix) { return $null }
    $payload = From-B64Url $parts[1]; $sig = From-B64Url $parts[2]
    if ($payload -eq $null -or $sig -eq $null) { return $null }
    return @{ Valid = [CueCrypto]::Verify($PublicKey, $payload, $sig); Text = $Utf8.GetString($payload) }
}
# Key is valid up to and including its last day
function Test-Key([string]$raw) {
    $st = Get-SignedText $raw "CUE1"
    if ($st -eq $null) { return @{ Ok = $false; Problem = (T "This is not a valid Cue key." "Das ist kein gültiger Cue Schlüssel.") } }
    if (-not $st.Valid) { return @{ Ok = $false; Problem = (T "This key is invalid." "Dieser Schlüssel ist ungültig.") } }
    $f = $st.Text.Split('|')
    if (-not (($f.Count -eq 4 -and $f[0] -eq "v1") -or ($f.Count -eq 5 -and $f[0] -eq "v2"))) {
        return @{ Ok = $false; Problem = (T "This is not a valid Cue key." "Das ist kein gültiger Cue Schlüssel.") }
    }
    if ($Destroyed -contains $f[3]) { return @{ Ok = $false; Problem = (T "This key has been revoked by Luc Porchet." "Dieser Schlüssel wurde von Luc Porchet gesperrt.") } }
    # Ablauf: yyyy-MM-dd (bis und mit diesem Tag) oder yyyy-MM-ddTHH:mm:ssZ (bis genau zu dieser Zeit, ab 1.5)
    $lastDay = $null; $until = $null; $timed = $false
    if ($f[2] -ne "unbegrenzt") {
        try {
            if ($f[2].Contains("T")) {
                $until = [DateTime]::Parse($f[2], [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]"AssumeUniversal, AdjustToUniversal").ToLocalTime()
                $lastDay = $until; $timed = $true
            } else {
                $lastDay = [DateTime]::ParseExact($f[2], "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture)
                $until = $lastDay.AddDays(1)
            }
        } catch { return @{ Ok = $false; Problem = (T "This is not a valid Cue key." "Das ist kein gültiger Cue Schlüssel.") } }
    }
    $info = @{ Ok = $true; Name = $f[1]; LastDay = $lastDay; Until = $until; Timed = $timed; Serial = $f[3]; Url = $(if ($f.Count -eq 5) { $f[4] } else { $null }) }
    if ($until -ne $null -and (Get-Date) -ge $until) {
        return @{ Ok = $false; Problem = (T "The key for $($f[1]) expired on $(Format-Day $lastDay $timed)." "Der Schlüssel von $($f[1]) ist am $(Format-Day $lastDay $timed) abgelaufen.") }
    }
    return $info
}
function Format-Day($d, [bool]$timed = $false) {
    if ($d -eq $null) { return (T "never" "unbegrenzt") }
    if ($timed) { return $d.ToString("d MMMM yyyy, HH:mm", $Culture) }
    return $d.ToString("d MMMM yyyy", $Culture)
}
function Get-List([string]$raw) {
    if (-not $raw) { return $null }
    $st = Get-SignedText $raw "CUEREV1"
    if ($st -eq $null -or -not $st.Valid) { return $null }
    $f = $st.Text.Split('|')
    if ($f.Count -ne 4 -or $f[0] -ne "v1") { return $null }
    return @{ Time = [long]$f[1]; MaxOff = [int]$f[2]; Serials = @($f[3].Split(',') | Where-Object { $_ -ne "" }) }
}

# Windows update info: same format as cue-update.txt on the Mac, own file cue-update-win.txt in the same Gist
# CUEUPD1.<data>.<signature>, data: v1|latest|minimum|ZIP address|SHA256|check-in repo|check-in token (hidden)|notes (base64)
function Unhide-Token([string]$s) {
    $b = From-B64Url $s
    if (-not $b -or $b.Count -eq 0) { return "" }
    $x = [byte[]]@($b | ForEach-Object { $_ -bxor 0x5A })
    [array]::Reverse($x)
    return $Utf8.GetString($x)
}
function Get-Manifest([string]$raw) {
    if (-not $raw) { return $null }
    $st = Get-SignedText $raw "CUEUPD1"
    if ($st -eq $null -or -not $st.Valid) { return $null }
    $f = $st.Text.Split('|')
    if ($f.Count -ne 8 -or $f[0] -ne "v1") { return $null }
    $nb = From-B64Url $f[7]
    $notes = ""; if ($nb -and $nb.Count -gt 0) { $notes = $Utf8.GetString($nb) }
    return @{ Latest = $f[1]; Minimum = $f[2]; Zip = $f[3]; Sha = $f[4].ToLower(); Repo = $f[5]; Token = (Unhide-Token $f[6]); Notes = $notes }
}
# "1.10" > "1.9"
function Test-Newer([string]$a, [string]$b) {
    try {
        $x = @($a.Split('.') | ForEach-Object { [int]$_ }); $y = @($b.Split('.') | ForEach-Object { [int]$_ })
        for ($n = 0; $n -lt [Math]::Max($x.Count, $y.Count); $n++) {
            $p = 0; if ($n -lt $x.Count) { $p = $x[$n] }
            $q = 0; if ($n -lt $y.Count) { $q = $y[$n] }
            if ($p -ne $q) { return ($p -gt $q) }
        }
    } catch {}
    return $false
}
function Get-ManifestUrl([string]$listUrl) { return $listUrl.Substring(0, $listUrl.LastIndexOf('/') + 1) + "cue-update-win.txt" }
function Get-NamesUrl([string]$listUrl) { return $listUrl.Substring(0, $listUrl.LastIndexOf('/') + 1) + "cue-names.txt" }
# CUENAME1.<data>.<signature>, data: v1|time|NUMBER:name base64url,...
function Get-NameList([string]$raw) {
    if (-not $raw) { return $null }
    $st = Get-SignedText $raw "CUENAME1"
    if ($st -eq $null -or -not $st.Valid) { return $null }
    $f = $st.Text.Split('|')
    if ($f.Count -ne 3 -or $f[0] -ne "v1") { return $null }
    $names = @{}
    foreach ($e in $f[2].Split(',')) {
        $kv = $e.Split(@(':'), 2)
        if ($kv.Count -ne 2) { continue }
        $b = From-B64Url $kv[1]
        if ($b -and $b.Count -gt 0) { $names[$kv[0]] = $Utf8.GetString($b) }
    }
    return @{ Time = [long]$f[1]; Names = $names }
}

# ---------- License state ----------
$script:Info = $null; $script:Problem = $null; $script:CanRetry = $false
$script:Fetch = $null; $script:FetchDone = $null; $script:FetchKind = ""; $script:LastCheck = [DateTime]::MinValue; $script:PendingKey = $null
$script:ListUrl = $null; $script:RequiredUpdate = $null; $script:UpdTask = $null; $script:Updating = $false; $script:UpdError = $null

function Get-ClockProblem {
    $now = (Get-Date).ToUniversalTime()
    $seen = (Get-Date-Setting "lastSeen").ToUniversalTime()
    if ($now.AddDays(2) -lt $seen) { return (T "The date on this PC is wrong. Please check the date and time." "Das Datum auf diesem PC stimmt nicht. Bitte Datum und Uhrzeit prüfen.") }
    if ($now -gt $seen) { Set-Date-Setting "lastSeen" $now; Save-Settings }
    return $null
}

function Update-License {
    $script:CanRetry = $false
    $script:RequiredUpdate = $null
    $key = $script:S["license"]
    if (-not $key) { $script:Info = $null; $script:Problem = $null; return }
    $p = Get-ClockProblem
    if ($p) { $script:Info = $null; $script:Problem = $p; return }
    $i = Test-Key $key
    if (-not $i.Ok) { $script:Info = $null; $script:Problem = $i.Problem; return }
    if ($i.Url) {
        $list = Get-List $script:S["revList"]
        $maxOff = 7; if ($list) { $maxOff = $list.MaxOff }
        if ($list -and ($list.Serials -contains $i.Serial)) {
            $script:Info = $null; $script:CanRetry = $true
            $script:Problem = T "This key has been revoked by Luc Porchet." "Dieser Schlüssel wurde von Luc Porchet gesperrt."
            return
        }
        $last = Get-Date-Setting "lastOnline"
        if ((Get-Date).ToUniversalTime() -gt $last.ToUniversalTime().AddDays($maxOff)) {
            $script:Info = $null; $script:CanRetry = $true
            $every = if ($maxOff -eq 1) { T "once a day" "jeden Tag" } else { T "every $maxOff days" "alle $maxOff Tage" }
            $script:Problem = T "Cue needs to go online $every to check that your key is still valid. Please connect to the internet." "Cue muss $every kurz online prüfen, ob dein Schlüssel noch gilt. Bitte mit dem Internet verbinden."
            return
        }
        # Minimum version from the signed update info: no access without the update
        $m = Get-Manifest $script:S["updManifest"]
        if ($m -and (Test-Newer $m.Minimum $Version)) {
            $script:Info = $null; $script:RequiredUpdate = $m
            $script:Problem = T "A new version of Cue ($($m.Latest)) is available. Please update to keep using Cue." "Eine neue Version von Cue ($($m.Latest)) ist da. Bitte aktualisieren, um Cue weiter zu nutzen."
            return
        }
    }
    $nl = Get-NameList $script:S["nameList"]
    if ($nl -and $nl.Names.ContainsKey($i.Serial) -and $nl.Names[$i.Serial]) { $i.Name = $nl.Names[$i.Serial] }
    $script:Info = $i; $script:Problem = $null
}

# Loads a signed file from the Gist in the background: "list" = revocation list, "manifest" = Windows update info.
# Older lists and older update infos than the saved ones are ignored.
function Start-Fetch([string]$url, [string]$kind, [scriptblock]$done) {
    if ($script:Fetch) { return }
    $wc = New-Object Net.WebClient
    $wc.Encoding = $Utf8
    $wc.Headers.Add("Cache-Control", "no-cache")
    $sep = if ($url.Contains("?")) { "&" } else { "?" }
    $u = New-Object Uri ($url + $sep + "t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    $script:Fetch = $wc.DownloadStringTaskAsync($u)
    $script:FetchDone = $done
    $script:FetchKind = $kind
    Show-State
}
function Complete-Fetch {
    $task = $script:Fetch; $done = $script:FetchDone; $kind = $script:FetchKind
    $script:Fetch = $null; $script:FetchDone = $null
    $script:LastCheck = Get-Date
    $ok = $false
    if ($task.Status -eq [Threading.Tasks.TaskStatus]::RanToCompletion -and $kind -eq "names") {
        $text = $task.Result.Trim()
        $n = Get-NameList $text
        if ($n) {
            $old = Get-NameList $script:S["nameList"]
            $oldTime = 0; if ($old) { $oldTime = $old.Time }
            if ($n.Time -ge $oldTime) { $script:S["nameList"] = $text; Save-Settings }
            $ok = $true
        }
    } elseif ($task.Status -eq [Threading.Tasks.TaskStatus]::RanToCompletion -and $kind -eq "manifest") {
        $text = $task.Result.Trim()
        $m = Get-Manifest $text
        if ($m) {
            $old = Get-Manifest $script:S["updManifest"]
            if (-not $old -or -not (Test-Newer $old.Latest $m.Latest)) { $script:S["updManifest"] = $text; Save-Settings }
            $ok = $true
        }
    } elseif ($task.Status -eq [Threading.Tasks.TaskStatus]::RanToCompletion) {
        $text = $task.Result.Trim()
        $list = Get-List $text
        if ($list) {
            $old = Get-List $script:S["revList"]
            $oldTime = 0; if ($old) { $oldTime = $old.Time }
            if ($list.Time -ge $oldTime) {
                $script:S["revList"] = $text
                Set-Date-Setting "lastOnline" (Get-Date)
                Save-Settings
                $ok = $true
            }
        }
    }
    if ($done) { & $done $ok }
    Show-State
}

# Checks the saved key; revocable keys fetch the list at most every 3 hours
function Refresh-License([bool]$force = $false) {
    Update-License
    $key = $script:S["license"]
    if ($key) {
        $i = Test-Key $key
        if ($i.Ok -and $i.Url -and ($force -or ((Get-Date) - $script:LastCheck).TotalHours -gt 3)) {
            $script:ListUrl = $i.Url
            Start-Fetch $i.Url "list" {
                param($ok)
                Start-Fetch (Get-ManifestUrl $script:ListUrl) "manifest" {
                    param($ok2)
                    Start-Fetch (Get-NamesUrl $script:ListUrl) "names" { param($ok3) Update-License; Send-Checkin }
                }
            }
        }
    }
    Show-State
}

function Activate-Key([string]$raw) {
    $key = $raw -replace '\s', ''
    $p = Get-ClockProblem
    if ($p) { $script:Problem = $p; Show-State; return }
    $i = Test-Key $key
    if (-not $i.Ok) { $script:Info = $null; $script:Problem = $i.Problem; $script:CanRetry = $false; Show-State; return }
    if (-not $i.Url) { $script:S["license"] = $key; Save-Settings; Update-License; Show-State; return }
    $script:PendingKey = $key
    $script:ListUrl = $i.Url
    Start-Fetch $i.Url "list" {
        param($ok)
        if (-not $ok) {
            $script:Problem = T "No connection. Cue needs to be online once to activate." "Keine Verbindung. Zum Freischalten muss Cue einmal online sein."
            $script:CanRetry = $false
            return
        }
        $script:S["license"] = $script:PendingKey; Save-Settings
        Update-License
        Start-Fetch (Get-ManifestUrl $script:ListUrl) "manifest" {
                    param($ok2)
                    Start-Fetch (Get-NamesUrl $script:ListUrl) "names" { param($ok3) Update-License; Send-Checkin }
                }
    }
}

# Reports version and key number to Luc's check-in repo, at most every 6 hours and right after a version change
function Send-Checkin {
    $m = Get-Manifest $script:S["updManifest"]
    if (-not $m -or -not $m.Repo -or -not $m.Token -or -not $script:Info) { return }
    $tag = "$Version|$($script:Info.Serial)"
    $last = Get-Date-Setting "lastCheckin"
    if (((Get-Date).ToUniversalTime() - $last.ToUniversalTime()).TotalHours -lt 6 -and $script:S["lastCheckinVersion"] -eq $tag) { return }
    Set-Date-Setting "lastCheckin" (Get-Date); $script:S["lastCheckinVersion"] = $tag; Save-Settings
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $PowerShellExe
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File " + (Quote-Arg (Join-Path $PSScriptRoot "checkin.ps1")) + " " + (Quote-Arg $script:Info.Serial) + " " + (Quote-Arg $Version) + " " + (Quote-Arg $m.Repo)
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.EnvironmentVariables["CUE_TOKEN"] = $m.Token
    try { [void][Diagnostics.Process]::Start($psi) } catch {}
}

# Downloads the update, checks SHA256, then the installer replaces Cue quietly and starts it again
function Start-Update {
    $m = $script:RequiredUpdate
    if (-not $m -or $script:UpdTask) { return }
    $wc = New-Object Net.WebClient
    $script:UpdTask = $wc.DownloadDataTaskAsync((New-Object Uri $m.Zip))
    $script:Updating = $true; $script:UpdError = $null
    Show-State
}
function Complete-Update {
    $task = $script:UpdTask; $script:UpdTask = $null
    try {
        if ($task.Status -ne [Threading.Tasks.TaskStatus]::RanToCompletion) { throw (T "Download failed. Please try again." "Download fehlgeschlagen. Bitte nochmals versuchen.") }
        $data = $task.Result
        $hasher = [Security.Cryptography.SHA256]::Create()
        $sha = [BitConverter]::ToString($hasher.ComputeHash($data)).Replace("-", "").ToLower()
        if ($sha -ne $script:RequiredUpdate.Sha) { throw (T "The update is damaged (checksum does not match)." "Das Update ist beschädigt (Prüfsumme stimmt nicht).") }
        $base = Join-Path $env:TEMP ("cue-update-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
        New-Item -ItemType Directory -Force -Path $base | Out-Null
        $zip = Join-Path $base "update.zip"
        [IO.File]::WriteAllBytes($zip, $data)
        Expand-Archive -Path $zip -DestinationPath (Join-Path $base "x") -Force
        $inst = Get-ChildItem -Path (Join-Path $base "x") -Recurse -Filter "install.ps1" | Select-Object -First 1
        if (-not $inst) { throw (T "The update is incomplete." "Das Update ist unvollständig.") }
        Get-ChildItem -Path (Join-Path $base "x") -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
        Start-Process -FilePath $PowerShellExe -WindowStyle Hidden -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " + (Quote-Arg $inst.FullName) + " -Quiet")
        $form.Close()
    } catch {
        $script:Updating = $false; $script:UpdError = $_.Exception.Message
        Show-State
    }
}

# ---------- History (%LOCALAPPDATA%\Cue\history.txt, newest last) ----------
function Get-History {
    if (-not (Test-Path $HistoryFile)) { return @() }
    $lines = @([IO.File]::ReadAllLines($HistoryFile, $Utf8) | Where-Object { $_ -ne "" })
    [array]::Reverse($lines)
    $seen = @{}; $out = @()
    foreach ($l in $lines) {
        if ($seen.ContainsKey($l)) { continue }
        $seen[$l] = $true
        if (Test-Path -LiteralPath $l) { $out += Get-Item -LiteralPath $l }
    }
    return $out
}
function Remove-FromHistory([string]$path) {
    if (-not (Test-Path $HistoryFile)) { return }
    $rest = @([IO.File]::ReadAllLines($HistoryFile, $Utf8) | Where-Object { $_ -ne "" -and $_ -ne $path })
    [IO.File]::WriteAllText($HistoryFile, (($rest -join "`r`n") + $(if ($rest) { "`r`n" } else { "" })), $Utf8)
}
function Format-Size([long]$b) {
    if ($b -ge 1GB) { return "{0:0.00} GB" -f ($b / 1GB) }
    if ($b -ge 1MB) { return "{0:0.0} MB" -f ($b / 1MB) }
    return "{0:0} KB" -f ($b / 1KB)
}

# ---------- Window ----------
$g = [Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
$Scale = $g.DpiX / 96.0
$g.Dispose()
function S([double]$n) { return [int][Math]::Round($n * $Scale) }
function P([double]$x, [double]$y) { return New-Object Drawing.Point((S $x), (S $y)) }
function Z([double]$w, [double]$h) { return New-Object Drawing.Size((S $w), (S $h)) }

$FontUI = New-Object Drawing.Font("Segoe UI", 10)
$FontBold = New-Object Drawing.Font("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$FontTitle = New-Object Drawing.Font("Segoe UI", 20, [Drawing.FontStyle]::Bold)
$FontSmall = New-Object Drawing.Font("Segoe UI", 8.5)
$FontMono = New-Object Drawing.Font("Consolas", 10)
$Grey = [Drawing.Color]::FromArgb(110, 110, 110)
$Accent = [Drawing.Color]::FromArgb(255, 110, 50)

$form = New-Object Windows.Forms.Form
$form.Text = "Cue"
$form.Font = $FontUI
$form.AutoScaleMode = "None"
$wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.ClientSize = New-Object Drawing.Size([Math]::Min((S 640), $wa.Width - (S 40)), [Math]::Min((S 720), $wa.Height - (S 60)))
$form.MinimumSize = New-Object Drawing.Size([Math]::Min((S 560), $wa.Width - (S 40)), [Math]::Min((S 560), $wa.Height - (S 40)))
$form.StartPosition = "CenterScreen"
$form.BackColor = [Drawing.Color]::White
$iconPath = Join-Path $PSScriptRoot "Cue.ico"
if (Test-Path $iconPath) { try { $form.Icon = New-Object Drawing.Icon($iconPath) } catch {} }
$logoPath = Join-Path $PSScriptRoot "Cue.png"
$logo = $null
if (Test-Path $logoPath) { try { $logo = [Drawing.Image]::FromFile($logoPath) } catch {} }

function New-Label([string]$text, [int]$x, [int]$y, $font = $FontUI) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text; $l.Location = (P $x $y); $l.AutoSize = $true; $l.Font = $font
    return $l
}
function New-Button([string]$text, [int]$x, [int]$y, [int]$w = 90) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text; $b.Location = (P $x $y); $b.Size = (Z $w 30)
    $b.FlatStyle = "System"
    return $b
}

# --- Main view ---
$main = New-Object Windows.Forms.Panel
$main.Dock = "Fill"
$main.Padding = New-Object Windows.Forms.Padding(0)

if ($logo) {
    $pic = New-Object Windows.Forms.PictureBox
    $pic.Image = $logo; $pic.SizeMode = "Zoom"; $pic.Location = (P 20 16); $pic.Size = (Z 52 52)
    $main.Controls.Add($pic)
}
$main.Controls.Add((New-Label "Cue" 78 14 $FontTitle))
$sub = New-Label (T "Clips in the highest quality, straight to Downloads" "Clips in höchster Qualität, direkt in Downloads") 82 52
$sub.ForeColor = $Grey
$main.Controls.Add($sub)

$main.Controls.Add((New-Label "Link" 20 90 $FontBold))
$tbLink = New-Object Windows.Forms.TextBox
$tbLink.Location = (P 20 114); $tbLink.Size = (Z 500 26)
$main.Controls.Add($tbLink)
$btnPaste = New-Button (T "Paste" "Einfügen") 530 112
$main.Controls.Add($btnPaste)

$main.Controls.Add((New-Label (T "What to save?" "Was speichern?") 20 152 $FontBold))
$rbAudio = New-Object Windows.Forms.RadioButton; $rbAudio.Text = T "Audio only" "Nur Audio"; $rbAudio.Location = (P 22 176); $rbAudio.AutoSize = $true; $rbAudio.Checked = $true
$rbVideo = New-Object Windows.Forms.RadioButton; $rbVideo.Text = T "Video with sound" "Video mit Ton"; $rbVideo.Location = (P 150 176); $rbVideo.AutoSize = $true
$rbBoth = New-Object Windows.Forms.RadioButton; $rbBoth.Text = T "Video + Audio" "Video + Audio"; $rbBoth.Location = (P 310 176); $rbBoth.AutoSize = $true
$main.Controls.AddRange(@($rbAudio, $rbVideo, $rbBoth))
$lblHint = New-Label "" 20 204 $FontSmall
$lblHint.ForeColor = $Grey
$main.Controls.Add($lblHint)
function Update-Hint {
    if ($rbAudio.Checked) { $lblHint.Text = T "1 file .m4a, Apple Lossless 24 bit" "1 Datei .m4a, Apple Lossless 24 bit" }
    elseif ($rbVideo.Checked) { $lblHint.Text = T "1 file .mp4, up to 4K, sound included" "1 Datei .mp4, bis 4K, Ton im Video" }
    else { $lblHint.Text = T "2 files: .mp4 and a separate .m4a" "2 Dateien: .mp4 und .m4a separat" }
}
foreach ($rb in @($rbAudio, $rbVideo, $rbBoth)) { $rb.Add_CheckedChanged({ Update-Hint }) }
Update-Hint

$main.Controls.Add((New-Label "Start" 20 236 $FontBold))
$lblEnd = New-Label (T "End" "Ende") 330 236 $FontBold
$main.Controls.Add($lblEnd)
$tbStart = New-Object Windows.Forms.TextBox; $tbStart.Location = (P 20 260); $tbStart.Size = (Z 290 26); $tbStart.Font = $FontMono
$tbEnd = New-Object Windows.Forms.TextBox; $tbEnd.Location = (P 330 260); $tbEnd.Size = (Z 290 26); $tbEnd.Font = $FontMono; $tbEnd.Enabled = $false
$main.Controls.AddRange(@($tbStart, $tbEnd))
$h1 = New-Label (T "e.g. 2.22.13, empty = whole video" "z.B. 2.22.13, leer = ganzes Video") 20 290 $FontSmall; $h1.ForeColor = $Grey
$h2 = New-Label (T "empty = until the end" "leer = bis zum Schluss") 330 290 $FontSmall; $h2.ForeColor = $Grey
$main.Controls.AddRange(@($h1, $h2))
$tbStart.Add_TextChanged({ $tbEnd.Enabled = ($tbStart.Text.Trim() -ne "") })

$btnGo = New-Button (T "Go" "Los") 20 320 110
$btnGo.Font = $FontBold
$main.Controls.Add($btnGo)
$form.AcceptButton = $btnGo
$lblPhase = New-Label "" 142 326
$lblPhase.ForeColor = $Grey
$main.Controls.Add($lblPhase)
$lblPct = New-Label "" 570 326; $lblPct.ForeColor = $Grey
$main.Controls.Add($lblPct)
$bar = New-Object Windows.Forms.ProgressBar
$bar.Location = (P 20 358); $bar.Size = (Z 600 10)
$bar.Visible = $false
$main.Controls.Add($bar)
$lblError = New-Object Windows.Forms.Label
$lblError.Location = (P 20 374); $lblError.Size = (Z 600 40)
$lblError.ForeColor = [Drawing.Color]::FromArgb(200, 30, 30)
$main.Controls.Add($lblError)

$lblClips = New-Label (T "Previous clips" "Bisherige Clips") 20 418 $FontBold
$main.Controls.Add($lblClips)
$list = New-Object Windows.Forms.ListView
$list.View = "Details"; $list.FullRowSelect = $true; $list.HideSelection = $false; $list.MultiSelect = $false
$list.Location = (P 20 442); $list.Size = (Z 600 200)
[void]$list.Columns.Add((T "Name" "Name"), (S 330))
[void]$list.Columns.Add((T "Type" "Typ"), (S 50))
[void]$list.Columns.Add((T "Date" "Datum"), (S 130))
[void]$list.Columns.Add((T "Size" "Grösse"), (S 80))
$main.Controls.Add($list)
$btnPlay = New-Button (T "Play" "Abspielen") 20 650 100
$btnShow = New-Button (T "Show in folder" "Im Ordner zeigen") 126 650 140
$btnRemove = New-Button (T "Remove from list" "Aus Liste entfernen") 272 650 150
$main.Controls.AddRange(@($btnPlay, $btnShow, $btnRemove))
$lblFooter = New-Label "" 20 694 $FontSmall; $lblFooter.ForeColor = $Grey
$main.Controls.Add($lblFooter)
$lblCopy = New-Label ([string][char]0x00A9 + " 2026 Luc Porchet") 520 694 $FontSmall; $lblCopy.ForeColor = $Grey
$main.Controls.Add($lblCopy)

# Places everything from the real window size (any size, any screen scaling)
function Layout-Main {
    $w = $main.ClientSize.Width; $h = $main.ClientSize.Height
    if ($w -le 0 -or $h -le 0) { return }
    $right = $w - (S 20)
    $btnPaste.Left = $right - $btnPaste.Width
    $tbLink.Width = [Math]::Max((S 120), $btnPaste.Left - (S 10) - $tbLink.Left)
    $col = [int](($w - (S 60)) / 2)
    $tbStart.Width = $col
    $x2 = (S 40) + $col
    $lblEnd.Left = $x2; $tbEnd.Left = $x2; $tbEnd.Width = $col; $h2.Left = $x2
    $lblPct.Left = $right - $lblPct.Width
    $bar.Width = $right - $bar.Left
    $lblError.Width = $right - $lblError.Left
    $footY = $h - (S 26)
    $lblFooter.Top = $footY
    $lblCopy.Top = $footY; $lblCopy.Left = $right - $lblCopy.Width
    $btnY = $footY - (S 40)
    foreach ($b in @($btnPlay, $btnShow, $btnRemove)) { $b.Top = $btnY }
    $list.Width = $right - $list.Left
    $list.Height = [Math]::Max((S 60), $btnY - (S 8) - $list.Top)
}
$main.Add_Resize({ Layout-Main })

function Load-ClipList {
    $list.BeginUpdate()
    $list.Items.Clear()
    foreach ($f in (Get-History)) {
        $it = New-Object Windows.Forms.ListViewItem($f.BaseName)
        [void]$it.SubItems.Add($f.Extension.TrimStart('.').ToUpper())
        [void]$it.SubItems.Add($f.LastWriteTime.ToString("d MMM yyyy, HH:mm", $Culture))
        [void]$it.SubItems.Add((Format-Size $f.Length))
        $it.Tag = $f.FullName
        [void]$list.Items.Add($it)
    }
    $list.EndUpdate()
    $lblClips.Text = (T "Previous clips" "Bisherige Clips") + $(if ($list.Items.Count -gt 0) { "  ($($list.Items.Count))" } else { "" })
    $has = $list.Items.Count -gt 0
    $btnPlay.Enabled = $has; $btnShow.Enabled = $has; $btnRemove.Enabled = $has
}
function Get-SelectedClip {
    if ($list.SelectedItems.Count -gt 0) { return [string]$list.SelectedItems[0].Tag }
    if ($list.Items.Count -gt 0) { return [string]$list.Items[0].Tag }
    return $null
}
$btnPlay.Add_Click({ $p = Get-SelectedClip; if ($p) { Start-Process -FilePath $p } })
$list.Add_DoubleClick({ $p = Get-SelectedClip; if ($p) { Start-Process -FilePath $p } })
$btnShow.Add_Click({ $p = Get-SelectedClip; if ($p) { Start-Process -FilePath "explorer.exe" -ArgumentList "/select,`"$p`"" } })
$btnRemove.Add_Click({ $p = Get-SelectedClip; if ($p) { Remove-FromHistory $p; Load-ClipList } })

# --- Lock view ---
$lock = New-Object Windows.Forms.Panel
$lock.Dock = "Fill"
if ($logo) {
    $pic2 = New-Object Windows.Forms.PictureBox
    $pic2.Image = $logo; $pic2.SizeMode = "Zoom"; $pic2.Size = (Z 96 96); $pic2.Location = (P 272 150)
    $lock.Controls.Add($pic2)
}
function New-CenterLabel([string]$text, [int]$y, [int]$h, $font) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $text; $l.Font = $font; $l.TextAlign = "MiddleCenter"
    $l.Location = (P 20 $y); $l.Size = (Z 600 $h)
    return $l
}
$lockTitle = New-CenterLabel (T "Cue is locked" "Cue ist gesperrt") 260 40 $FontTitle
$lockText = New-CenterLabel (T "You need a key from Luc Porchet to use Cue.`r`nPaste it here to unlock Cue." "Für Cue brauchst du einen Schlüssel von Luc Porchet.`r`nFüge ihn hier ein, um Cue freizuschalten.") 304 46 $FontUI
$lockText.ForeColor = $Grey
$lock.Controls.AddRange(@($lockTitle, $lockText))
$tbKey = New-Object Windows.Forms.TextBox
$tbKey.Location = (P 90 362); $tbKey.Size = (Z 360 26); $tbKey.Font = $FontMono
$lock.Controls.Add($tbKey)
$btnKeyPaste = New-Button (T "Paste" "Einfügen") 460 360
$lock.Controls.Add($btnKeyPaste)
$btnUnlock = New-Button (T "Unlock" "Freischalten") 250 404 140
$btnUnlock.Font = $FontBold
$lock.Controls.Add($btnUnlock)
$lockProblem = New-CenterLabel "" 446 60 $FontUI
$lockProblem.ForeColor = [Drawing.Color]::FromArgb(200, 30, 30)
$lock.Controls.Add($lockProblem)
$btnUpdate = New-Button (T "Update now" "Jetzt aktualisieren") 240 404 160
$btnUpdate.Font = $FontBold; $btnUpdate.Visible = $false
$lock.Controls.Add($btnUpdate)
$btnUpdate.Add_Click({ Start-Update })
$btnRetry = New-Button (T "Check again" "Nochmals prüfen") 250 512 140
$btnRetry.Visible = $false
$lock.Controls.Add($btnRetry)
$lockCopy = New-CenterLabel ([string][char]0x00A9 + " 2026 Luc Porchet") 690 20 $FontSmall
$lockCopy.ForeColor = $Grey
$lock.Controls.Add($lockCopy)

# Keeps the lock view centred in any window size (horizontally and vertically, like on the Mac)
function Layout-Lock {
    $w = $lock.ClientSize.Width; $h = $lock.ClientSize.Height
    if ($w -le 0 -or $h -le 0) { return }
    $cx = [int]($w / 2)
    $top = [Math]::Max((S 16), [int](($h - (S 400)) / 2))
    $full = [Math]::Max((S 200), $w - (S 40))
    if ($pic2) { $pic2.Location = New-Object Drawing.Point(($cx - [int]($pic2.Width / 2)), $top) }
    foreach ($pair in @(@($lockTitle, 110), @($lockText, 154), @($lockProblem, 296))) {
        $pair[0].Width = $full
        $pair[0].Location = New-Object Drawing.Point((S 20), ($top + (S $pair[1])))
    }
    $tbKey.Width = [Math]::Min((S 360), $w - (S 140))
    $row = $tbKey.Width + (S 10) + $btnKeyPaste.Width
    $tbKey.Location = New-Object Drawing.Point(($cx - [int]($row / 2)), ($top + (S 214)))
    $btnKeyPaste.Location = New-Object Drawing.Point(($tbKey.Right + (S 10)), ($top + (S 212)))
    foreach ($b in @($btnUnlock, $btnUpdate)) { $b.Location = New-Object Drawing.Point(($cx - [int]($b.Width / 2)), ($top + (S 254))) }
    $btnRetry.Location = New-Object Drawing.Point(($cx - [int]($btnRetry.Width / 2)), ($top + (S 362)))
    $lockCopy.Width = $full
    $lockCopy.Location = New-Object Drawing.Point((S 20), ($h - (S 30)))
}
$lock.Add_Resize({ Layout-Lock })

$btnKeyPaste.Add_Click({ $tbKey.Text = [Windows.Forms.Clipboard]::GetText() })
$btnUnlock.Add_Click({ if ($tbKey.Text.Trim() -ne "") { Activate-Key $tbKey.Text } })
$btnRetry.Add_Click({ Refresh-License $true })

$form.Controls.Add($main)
$form.Controls.Add($lock)

function Show-State {
    $unlocked = $script:Info -ne $null
    $main.Visible = $unlocked
    $lock.Visible = -not $unlocked
    if ($unlocked) {
        $i = $script:Info
        $until = if ($i.LastDay -eq $null) { T "never expires" "unbegrenzt gültig" } else { (T "valid until " "gültig bis ") + (Format-Day $i.LastDay $i.Timed) }
        $lblFooter.Text = "Cue $Version  " + [char]0x00B7 + "  " + (T "License: " "Lizenz: ") + $i.Name + "  " + [char]0x00B7 + "  " + $until
        $form.AcceptButton = $btnGo
        Layout-Main
    } else {
        $upd = $script:RequiredUpdate -ne $null
        $lockTitle.Text = if ($upd) { T "Update required" "Update nötig" } else { T "Cue is locked" "Cue ist gesperrt" }
        $lockText.Text = if ($upd) { $(if ($script:RequiredUpdate.Notes) { $script:RequiredUpdate.Notes } else { T "Cue for Windows $($script:RequiredUpdate.Latest)" "Cue für Windows $($script:RequiredUpdate.Latest)" }) } else { T "You need a key from Luc Porchet to use Cue.`r`nPaste it here to unlock Cue." "Für Cue brauchst du einen Schlüssel von Luc Porchet.`r`nFüge ihn hier ein, um Cue freizuschalten." }
        $tbKey.Visible = -not $upd; $btnKeyPaste.Visible = -not $upd; $btnUnlock.Visible = -not $upd
        $btnUpdate.Visible = $upd
        $btnUpdate.Enabled = -not $script:Updating
        # An earlier quiet update that failed leaves its message here
        $updErrFile = Join-Path $Tmp "update-error.txt"
        if ($upd -and -not $script:UpdError -and (Test-Path $updErrFile)) {
            try { $script:UpdError = [IO.File]::ReadAllText($updErrFile, $Utf8).Trim() } catch {}
            Remove-Item -Force $updErrFile -ErrorAction SilentlyContinue
        }
        $form.AcceptButton = if ($upd) { $btnUpdate } else { $btnUnlock }
        if ($script:Updating) { $lockProblem.ForeColor = $Grey; $lockProblem.Text = T "Updating Cue …" "Cue wird aktualisiert …"; $btnRetry.Visible = $false }
        elseif ($upd -and $script:UpdError) { $lockProblem.ForeColor = [Drawing.Color]::FromArgb(200, 30, 30); $lockProblem.Text = $script:UpdError; $btnRetry.Visible = $false }
        elseif ($upd) { $lockProblem.ForeColor = $Accent; $lockProblem.Text = $script:Problem; $btnRetry.Visible = $false }
        elseif ($script:Fetch) { $lockProblem.ForeColor = $Grey; $lockProblem.Text = T "Checking …" "Prüfe …"; $btnRetry.Visible = $false }
        else {
            $lockProblem.ForeColor = [Drawing.Color]::FromArgb(200, 30, 30)
            $lockProblem.Text = if ($script:Problem) { $script:Problem } else { "" }
            $btnRetry.Visible = $script:CanRetry
        }
        $btnUnlock.Enabled = -not $script:Fetch
        Layout-Lock
    }
}

# ---------- Download job (clip.ps1 runs as its own hidden process) ----------
$script:Proc = $null; $script:Cancelled = $false; $script:OutTask = $null; $script:ErrTask = $null
$PowerShellExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
$ClipScript = Join-Path $PSScriptRoot "clip.ps1"

# Empty becomes "_" (an argument starting with "-" would be read as a parameter name)
function Quote-Arg([string]$s) { if ($s -eq "") { $s = "_" }; return '"' + $s.Replace('"', '') + '"' }

function Start-Job-Cue {
    Refresh-License
    if ($script:Info -eq $null) { return }
    $link = $tbLink.Text.Trim()
    if ($link -eq "") { return }
    $mode = if ($rbAudio.Checked) { "audio" } elseif ($rbVideo.Checked) { "video" } else { "both" }
    $start = $tbStart.Text.Trim()
    $end = if ($start -eq "") { "" } else { $tbEnd.Text.Trim() }
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $PowerShellExe
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File " + (Quote-Arg $ClipScript) + " $mode " + (Quote-Arg $link) + " " + (Quote-Arg $start) + " " + (Quote-Arg $end)
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = "Hidden"
    # Read both streams in the background: errors before clip.ps1 even starts only show up here
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $lblError.Text = ""
    $script:Cancelled = $false
    foreach ($n in @("status", "err", "out")) { try { [IO.File]::WriteAllText((Join-Path $Tmp $n), "", $Utf8) } catch {} }
    $script:Proc = [Diagnostics.Process]::Start($psi)
    $script:OutTask = $script:Proc.StandardOutput.ReadToEndAsync()
    $script:ErrTask = $script:Proc.StandardError.ReadToEndAsync()
    $btnGo.Text = T "Cancel" "Abbrechen"
    $form.AcceptButton = $null
    $lblPhase.Text = T "Starting …" "Starte …"
    $lblPct.Text = ""
    $bar.Style = "Marquee"; $bar.Visible = $true
}

# Stops clip.ps1 and everything it started (yt-dlp, ffmpeg), nothing else
function Stop-Job-Cue {
    if ($script:Proc -and -not $script:Proc.HasExited) {
        $script:Cancelled = $true
        Start-Process -FilePath "taskkill.exe" -ArgumentList "/PID $($script:Proc.Id) /T /F" -WindowStyle Hidden -Wait
    }
}

function Poll-Job {
    $p = $script:Proc
    if (-not $p) { return }
    try {
        $lines = [IO.File]::ReadAllLines((Join-Path $Tmp "status"), $Utf8)
        if ($lines.Count -gt 0) {
            $s = $lines[$lines.Count - 1]
            if ($s.StartsWith("P ")) {
                $num = ($s.Substring(2) -replace '[^0-9.]', '')
                $v = 0.0
                if ([double]::TryParse($num, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$v)) {
                    $bar.Style = "Continuous"; $bar.Value = [int][Math]::Min(100, [Math]::Max(0, $v))
                    $lblPct.Text = "$([int]$v) %"
                }
            } elseif ($s.StartsWith("T ")) {
                $t = $s.Substring(2)
                if ($t -ne $lblPhase.Text) { $lblPhase.Text = $t; $bar.Style = "Marquee"; $lblPct.Text = "" }
            }
        }
    } catch {}
    if (-not $p.HasExited) { return }
    $script:Proc = $null
    $btnGo.Text = T "Go" "Los"
    $form.AcceptButton = $btnGo
    $bar.Visible = $false; $lblPct.Text = ""
    if ($script:Cancelled) { $lblPhase.Text = T "Cancelled" "Abgebrochen"; return }
    if ($p.ExitCode -eq 0) {
        $lblPhase.Text = T "Done" "Fertig"
        Load-ClipList
        $out = @([IO.File]::ReadAllLines((Join-Path $Tmp "out"), $Utf8) | Where-Object { $_ -ne "" })
        if ($out.Count -gt 0) { Start-Process -FilePath "explorer.exe" -ArgumentList "/select,`"$($out[0])`"" }
        [Media.SystemSounds]::Asterisk.Play()
    } else {
        $lblPhase.Text = ""
        $msg = ""
        try { $msg = [IO.File]::ReadAllText((Join-Path $Tmp "err"), $Utf8).Trim() } catch {}
        if ($msg -eq "" -and $script:ErrTask -and $script:ErrTask.Wait(2000)) {
            $msg = (@($script:ErrTask.Result -split "`r?`n" | Where-Object { $_.Trim() -ne "" }) | Select-Object -First 4) -join "`r`n"
        }
        if ($msg -eq "") { $msg = (T "Unknown error (code " "Unbekannter Fehler (Code ") + $p.ExitCode + ")" }
        $lblError.Text = $msg
    }
}

$btnGo.Add_Click({ if ($script:Proc) { Stop-Job-Cue } else { Start-Job-Cue } })
$btnPaste.Add_Click({ $t = [Windows.Forms.Clipboard]::GetText().Trim(); if ($t) { $tbLink.Text = $t } })

function Paste-IfLink {
    if ($script:Proc -or $tbLink.Text.Trim() -ne "") { return }
    try { $t = [Windows.Forms.Clipboard]::GetText().Trim(); if ($t.StartsWith("http")) { $tbLink.Text = $t } } catch {}
}

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 300
$timer.Add_Tick({
    try {
        if ($script:Fetch -and $script:Fetch.IsCompleted) { Complete-Fetch }
        if ($script:UpdTask -and $script:UpdTask.IsCompleted) { Complete-Update }
        Poll-Job
    } catch { $lblError.Text = $_.Exception.Message }
})
$hourly = New-Object Windows.Forms.Timer
$hourly.Interval = 3600000
$hourly.Add_Tick({ if (-not $script:Proc) { Refresh-License } })

$form.Add_Activated({ Paste-IfLink; if (-not $script:Proc) { Load-ClipList; Refresh-License } })
$form.Add_FormClosing({ Stop-Job-Cue })
$form.Add_Shown({
    if ($lock.Visible) {
        try { $t = [Windows.Forms.Clipboard]::GetText().Trim(); if ($t.StartsWith("CUE1.")) { $tbKey.Text = $t } } catch {}
    }
})

# ---------- Start animation (2.5 s, with sound, a click skips it) ----------
# 0 to 0.95 s: the waveform grows from the middle (riser in the sound)
# 0.95 s: drop, both cue markers hit, the section between them lights up orange to pink
# then "Cue" fades in, the bars pulse, everything fades out into the app
$SplashHeights = @(0.18, 0.30, 0.22, 0.42, 0.34, 0.55, 0.48, 0.72, 0.62, 0.90, 0.78, 1.00, 0.84, 0.68, 0.88, 0.60, 0.74, 0.46, 0.56, 0.36, 0.44, 0.26, 0.32, 0.20)
$SplashDrop = 0.95
$SplashEnd = 2.5
function Ease-Out([double]$x) { if ($x -le 0) { return 0.0 }; if ($x -ge 1) { return 1.0 }; return 1 - [Math]::Pow(1 - $x, 3) }
function Ease-In([double]$x) { if ($x -le 0) { return 0.0 }; if ($x -ge 1) { return 1.0 }; return [Math]::Pow($x, 3) }
function Argb([double]$a, [int]$r, [int]$g, [int]$b) { return [Drawing.Color]::FromArgb([int][Math]::Max(0, [Math]::Min(255, $a)), $r, $g, $b) }

function Draw-Splash($g, [int]$w, [int]$h) {
    $t = $script:SplashClock.Elapsed.TotalSeconds
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $n = $SplashHeights.Count
    $areaW = $w * 0.68; $left = ($w - $areaW) / 2; $pitch = $areaW / $n; $bw = $pitch * 0.56
    $cy = $h * 0.38; $maxH = $h * 0.40
    $selA = 7; $selB = 16
    $k = [Math]::Max(0.0, $t - $SplashDrop)
    $after = $t -ge $SplashDrop
    $flash = 0.0; if ($after) { $flash = [Math]::Exp(-$k * 3.2) }
    $mA = $left + $selA * $pitch; $mB = $left + $selB * $pitch

    # Light band between the markers
    if ($after) {
        $band = New-Object Drawing.SolidBrush (Argb (34 + 70 * $flash) 255 120 40)
        $g.FillRectangle($band, [float]$mA, [float]($cy - $maxH / 2 - $h * 0.04), [float]($mB - $mA), [float]($maxH + $h * 0.08))
        $band.Dispose()
    }
    # Bars: grow from the middle outwards; after the drop the selected ones glow and pulse
    $grey = New-Object Drawing.Pen ((Argb 80 255 255 255), [float]$bw)
    $grey.StartCap = [Drawing.Drawing2D.LineCap]::Round; $grey.EndCap = [Drawing.Drawing2D.LineCap]::Round
    $grad = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.PointF(0, [float]($cy - $maxH / 2))), (New-Object Drawing.PointF(0, [float]($cy + $maxH / 2 + 1))), (Argb 255 255 196 70), (Argb 255 240 50 110))
    $hot = New-Object Drawing.Pen ($grad, [float]$bw)
    $hot.StartCap = [Drawing.Drawing2D.LineCap]::Round; $hot.EndCap = [Drawing.Drawing2D.LineCap]::Round
    for ($i = 0; $i -lt $n; $i++) {
        $delay = [Math]::Abs($i - ($n - 1) / 2) / ($n / 2) * 0.38
        $p = Ease-Out (($t - $delay) / 0.5)
        if ($p -le 0) { continue }
        $pulse = 1.0
        if ($after) { $pulse = 1 + 0.10 * [Math]::Sin(2 * [Math]::PI * 2.1 * $k + $i * 0.7) * [Math]::Exp(-$k * 1.1) + 0.12 * $flash }
        $bh = [Math]::Max($bw, $maxH * $SplashHeights[$i] * $p * $pulse)
        $x = [float]($left + $i * $pitch + $pitch / 2)
        $half = [Math]::Max(0.5, ($bh - $bw) / 2)
        $pen = $grey; if ($after -and $i -ge $selA -and $i -lt $selB) { $pen = $hot }
        $g.DrawLine($pen, $x, [float]($cy - $half), $x, [float]($cy + $half))
    }
    $grey.Dispose(); $hot.Dispose(); $grad.Dispose()

    # Cue markers: race in from both sides and hit exactly on the drop, small recoil afterwards
    $in = Ease-In (($t - ($SplashDrop - 0.24)) / 0.24)
    if ($in -gt 0) {
        $recoil = 0.0; if ($after) { $recoil = [Math]::Sin($k * 38) * [Math]::Exp(-$k * 9) * $h * 0.02 }
        $xA = -$w * 0.1 + ($mA + $w * 0.1) * $in - $recoil
        $xB = $w * 1.1 - ($w * 1.1 - $mB) * $in + $recoil
        $lw = [float][Math]::Max(2, $h * 0.011)
        $top = $cy - $maxH / 2 - $h * 0.07; $bot = $cy + $maxH / 2 + $h * 0.07
        $tw = $h * 0.035
        $line = New-Object Drawing.Pen ([Drawing.Color]::White, $lw)
        $line.StartCap = [Drawing.Drawing2D.LineCap]::Round; $line.EndCap = [Drawing.Drawing2D.LineCap]::Round
        $tri = New-Object Drawing.SolidBrush (Argb 255 255 140 40)
        foreach ($mx in @($xA, $xB)) {
            $g.DrawLine($line, [float]$mx, [float]$bot, [float]$mx, [float]$top)
            $pts = [Drawing.PointF[]]@(
                (New-Object Drawing.PointF([float]($mx - $tw), [float]($top - $tw * 1.1))),
                (New-Object Drawing.PointF([float]($mx + $tw), [float]($top - $tw * 1.1))),
                (New-Object Drawing.PointF([float]$mx, [float]($top + $tw * 0.35))))
            $g.FillPolygon($tri, $pts)
        }
        $line.Dispose(); $tri.Dispose()
    }

    # Title and copyright fade in from below
    $a = Ease-Out (($t - 1.05) / 0.5)
    if ($a -gt 0) {
        $sf = New-Object Drawing.StringFormat
        $sf.Alignment = [Drawing.StringAlignment]::Center
        $f1 = New-Object Drawing.Font("Segoe UI Semibold", [float]($h * 0.12), [Drawing.FontStyle]::Bold, [Drawing.GraphicsUnit]::Pixel)
        $f2 = New-Object Drawing.Font("Segoe UI", [float]($h * 0.042), [Drawing.FontStyle]::Regular, [Drawing.GraphicsUnit]::Pixel)
        $b1 = New-Object Drawing.SolidBrush (Argb (255 * $a) 255 255 255)
        $b2 = New-Object Drawing.SolidBrush (Argb (150 * $a) 255 255 255)
        $dy = (1 - $a) * $h * 0.04
        $g.DrawString("Cue", $f1, $b1, [float]($w / 2), [float]($h * 0.725 + $dy), $sf)
        $g.DrawString([string][char]0x00A9 + " 2026 Luc Porchet", $f2, $b2, [float]($w / 2), [float]($h * 0.875 + $dy), $sf)
        $f1.Dispose(); $f2.Dispose(); $b1.Dispose(); $b2.Dispose(); $sf.Dispose()
    }
    # Short white flash on the drop
    if ($flash -gt 0.02) {
        $fl = New-Object Drawing.SolidBrush (Argb (46 * $flash) 255 255 255)
        $g.FillRectangle($fl, 0, 0, $w, $h)
        $fl.Dispose()
    }
}

function Show-Splash {
    $script:Splash = New-Object Windows.Forms.Form
    $sp = $script:Splash
    $sp.FormBorderStyle = "None"; $sp.StartPosition = "CenterScreen"; $sp.ShowInTaskbar = $false; $sp.TopMost = $true
    $sp.ClientSize = (Z 560 340)
    $sp.BackColor = [Drawing.Color]::FromArgb(18, 16, 26)
    $sp.GetType().GetProperty("DoubleBuffered", [Reflection.BindingFlags]"Instance, NonPublic").SetValue($sp, $true, $null)
    if ($form.Icon) { $sp.Icon = $form.Icon }
    $script:SplashClock = New-Object Diagnostics.Stopwatch
    $script:SplashSound = $null
    $wav = Join-Path $PSScriptRoot "Cue-intro.wav"
    if (Test-Path $wav) { try { $script:SplashSound = New-Object Media.SoundPlayer $wav; $script:SplashSound.Load() } catch { $script:SplashSound = $null } }
    $sp.Add_Paint({
        param($s, $e)
        try { Draw-Splash $e.Graphics $s.ClientSize.Width $s.ClientSize.Height } catch {}
    })
    $sp.Add_Click({ if ($script:SplashSound) { $script:SplashSound.Stop() }; $script:Splash.Close() })
    $sp.Add_KeyDown({ if ($script:SplashSound) { $script:SplashSound.Stop() }; $script:Splash.Close() })
    $sp.Add_Shown({
        [CueNative]::RoundCorners($script:Splash.Handle)
        if ($script:SplashSound) { try { $script:SplashSound.Play() } catch {} }
        $script:SplashClock.Start()
        $script:SplashTimer.Start()
    })
    $script:SplashTimer = New-Object Windows.Forms.Timer
    $script:SplashTimer.Interval = 15
    $script:SplashTimer.Add_Tick({
        $t = $script:SplashClock.Elapsed.TotalSeconds
        if ($t -ge $SplashEnd) { $script:SplashTimer.Stop(); $script:Splash.Close(); return }
        if ($t -gt 2.05) { $script:Splash.Opacity = [Math]::Max(0.0, 1 - ($t - 2.05) / 0.45) }
        $script:Splash.Invalidate()
    })
    try { [void]$sp.ShowDialog() } catch {}
    $script:SplashTimer.Stop(); $script:SplashTimer.Dispose(); $sp.Dispose()
}

Show-Splash
Load-ClipList
Refresh-License
$timer.Start(); $hourly.Start()
[void]$form.ShowDialog()
$timer.Stop(); $hourly.Stop()
