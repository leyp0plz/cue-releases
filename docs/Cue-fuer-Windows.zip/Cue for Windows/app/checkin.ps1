﻿# Cue for Windows check-in  (c) 2026 Luc Porchet
# checkin.ps1 SERIAL VERSION REPO, token in the environment variable CUE_TOKEN (from the signed update info).
# Writes checkins/<SERIAL>.json in Luc's private check-in repo, so Cue Admin sees who has which version.
param([string]$Serial, [string]$Version, [string]$Repo)
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
try {
    $token = $env:CUE_TOKEN
    if (-not $token -or -not $Repo -or -not $Serial) { exit 0 }
    $headers = @{ Authorization = "Bearer $token"; Accept = "application/vnd.github+json"; "User-Agent" = "Cue-Windows" }
    $url = "https://api.github.com/repos/$Repo/contents/checkins/$Serial.json"
    $sha = $null
    try { $sha = (Invoke-RestMethod -Uri $url -Headers $headers -Method Get).sha } catch {}
    $c = [ordered]@{
        serial = $Serial
        version = $Version
        lastSeen = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        macOS = "Windows " + [Environment]::OSVersion.Version.ToString()
    }
    $json = $c | ConvertTo-Json -Compress
    $body = @{ message = "Check-in $Serial"; content = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($json)) }
    if ($sha) { $body.sha = $sha }
    Invoke-RestMethod -Uri $url -Headers $headers -Method Put -ContentType "application/json" -Body ($body | ConvertTo-Json) | Out-Null
} catch {}
